using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic.Entidades
{
  public static class FormatearPrecioExtencion
  {
    public static string FormatearPrecio(this double precio)
    {
      double p = precio;
      string precioStr = String.Format("$ {0:0.00}", p);

      return precioStr;
    }
  }
}
