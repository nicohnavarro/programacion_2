using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace ComiqueriaLogic.Entidades
{
  public class Sql
  {
    private SqlCommand comando;
    private SqlConnection conexion;

    public Sql()
    {
      string connectionStr = @"Data Source= .\SQLEXPRESS; Initial Cantalog=Comiqueria; Integrated Security= True";
      try
      {
        conexion = new SqlConnection(connectionStr);
        comando = new SqlCommand();
        comando.CommandType = CommandType.Text;
        comando.Connection = conexion;
      }
      catch (Exception e)
      {
        throw e;
      }
      finally
      {
        if (conexion.State == ConnectionState.Open)
          conexion.Close();
      }
    }

    public void Guardar(string tabla, string descripcion,double precio,int stock )
    {
      try
      {

        string consulta = String.Format("Insert into {0} (patente, tipo) Values ('{1}','{2}','{3}') ", tabla, descripcion, precio.ToString(), stock.ToString());
          comando.CommandText = consulta;
          conexion.Open();
          comando.ExecuteNonQuery();
      }
      catch (Exception e)
      {
         throw e;
      }
      finally
      {
          if (conexion.State == ConnectionState.Open)
          {
            conexion.Close();
          }
      }

    }

    public void Eliminar(string tabla,Producto producto)
    {
      try
      {
        string consulta = string.Format("Delete from {0} Where Codigo={1}", tabla, producto.Codigo);
        comando.CommandText = consulta;
        conexion.Open();
        comando.ExecuteNonQuery();
      }
      catch (Exception e)
      {

        throw e; 
      }
      finally
      {
        if(conexion.State==ConnectionState.Open)
        {
          conexion.Close();
        }
      }
    }

    public void Leer(string tabla, out List<Producto> datos)
    {
      datos = new List<Producto>();
      Producto producto;
      string consulta = String.Format("Select * from {0}", tabla);
      try
      {
        comando.CommandText = consulta;
        conexion.Open();
        SqlDataReader oDr = comando.ExecuteReader();

        while (oDr.Read())
        {
          int.TryParse(oDr["Codigo"].ToString(), out int codigo);
          string descripcion = oDr["Descripcion"].ToString();
          Double.TryParse(oDr["Precio"].ToString(), out double precio);
          int.TryParse(oDr["Stock"].ToString(), out int stock);
          producto = new Producto(codigo,descripcion,stock,precio);
          datos.Add(producto);
        }
      }
      catch (Exception e)
      {
        throw e;
      }
      finally
      {
        if (conexion.State == ConnectionState.Open)
        {
          conexion.Close();
        }
      }
    }
  }
}
