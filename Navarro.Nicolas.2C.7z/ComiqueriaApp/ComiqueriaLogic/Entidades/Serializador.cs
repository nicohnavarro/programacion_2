using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;
using System.Xml;
using System.IO;

namespace ComiqueriaLogic.Entidades
{
  public static class Serializador<T> where T:class,new()
  {
      public static void SerializarBinario(string path, T dato)
      {
        FileStream fs= new FileStream(path, FileMode.Create);
        BinaryFormatter ser;
        try
        {
           ser = new BinaryFormatter();
          ser.Serialize(fs, dato);
        }
        catch (ArgumentException e)
        {

          throw new ArgumentException("Otra Excepcion",e);
        }
        catch (DirectoryNotFoundException e)
        {
            throw new ComiqueriaException("Error: Directorio no encontrado", e);
        }
        catch (Exception e)
        {
             throw new Exception("Occurrio un Error, contacte al administrador", e);
        }
        finally
        {
          if (fs != null)
            fs.Close();
        }
      }

        public static void DeserializarBinario(string path, out T datos)
        {
              
              
              FileStream fs = new FileStream(path,FileMode.Open);
              BinaryFormatter ser = new BinaryFormatter();
              try
              {
                  datos = (T)ser.Deserialize(fs);
              }
              catch (Exception e)
              {

                  throw e;    
              }
              finally
              {
                  if (fs != null)
                  fs.Close();
              }
        }
        
        public static void SerializarXml(string path, T datos)
        {
           XmlSerializer ser = new XmlSerializer(typeof(T));
           XmlTextWriter writer = new XmlTextWriter(path, Encoding.UTF8);

            ser.Serialize(writer, datos);
             writer.Close();
        }

        public static void DeserializarXml(string tabla, out T datos)
        {
            XmlSerializer ser = new XmlSerializer(typeof(T));
            XmlTextReader reader = new XmlTextReader(tabla);
            try
            {
              ser = new XmlSerializer(typeof(T));
              reader = new XmlTextReader(tabla);
              datos = (T)ser.Deserialize(reader);
            }
            catch (Exception e)
            {

                throw e;
            }
             finally
            {
                if(reader!=null)
                reader.Close();
            }
     }
  }
}
