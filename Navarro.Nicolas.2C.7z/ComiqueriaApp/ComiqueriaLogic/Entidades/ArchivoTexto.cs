using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic.Entidades
{
  public static class ArchivoTexto
  {
    public static void Escribir(IArchivoTexto objecto,bool append)
    {
      StreamWriter sw = new StreamWriter(objecto.Ruta,append,Encoding.UTF8);
      
      try
      {
         
          sw.WriteLine(objecto.Texto);
      }
      catch(Exception e)
      {
        throw e;
      }
      finally
      {
        if (sw != null)
          sw.Close();
      }
    }

    public static  string Leer(string ruta)
    {
      string datos="";
      StreamReader sr = new StreamReader(ruta);
      while (!sr.EndOfStream)
      {
        datos = sr.ReadLine();

      }
      sr.Close();
      return datos;
    }

  }
}
