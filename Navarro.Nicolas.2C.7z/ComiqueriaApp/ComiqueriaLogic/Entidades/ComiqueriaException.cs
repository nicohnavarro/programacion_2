using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic.Entidades
{
  public class ComiqueriaException : Exception, IArchivoTexto
  {
    public ComiqueriaException(string mensaje) : base(mensaje)
    { }
    public ComiqueriaException(string mensaje, Exception inner) : base(mensaje, inner)
    {
      ArchivoTexto.Escribir(this, true);
    }

    public string Ruta
    {
      get
      {
        return string.Format("{0}-{1}", DateTime.Now.ToLongDateString(), Message);
      }
    }
    public string Texto
    {
      get
      {
        return string.Format("{0}log.txt", Environment.GetFolderPath(Environment.SpecialFolder.Desktop));
      }
    }
  }
}
