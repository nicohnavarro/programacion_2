using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ComiqueriaLogic.Entidades;

namespace UnitTestProject1
{
  [TestClass]
  public class TestUnitario
  {
    [TestMethod]
    public void TestFormatearPrecio()
    {
      //Arrange
      double numeroPrueba=10.00;
      string numeroPrecio; 
      string valido = "$ 10,00"; ;

      //Act
      numeroPrecio=numeroPrueba.FormatearPrecio();

      //Assert
      Assert.AreEqual(valido, numeroPrecio);
    }
  }
}
